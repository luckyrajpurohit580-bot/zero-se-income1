import { NextResponse } from "next/server";
import { sql, init } from "../../../../lib/db.js";
import { isAdmin } from "../../../../lib/admin.js";
export const dynamic = "force-dynamic";
export async function GET(req) {
  if (!isAdmin(req)) return NextResponse.json({ error: "login chahiye" }, { status: 401 });
  await init();
  const rows = await sql()`SELECT id,link,title,amount_paise,status,hidden,created_at,paid_at,payment_id FROM bids ORDER BY id DESC LIMIT 200`;
  const total = await sql()`SELECT COALESCE(SUM(amount_paise),0)::int AS t FROM bids WHERE status='paid'`;
  return NextResponse.json({ rows, totalRupees: total[0].t / 100 });
}
export async function POST(req) {
  if (!isAdmin(req)) return NextResponse.json({ error: "login chahiye" }, { status: 401 });
  const { id, action } = await req.json();
  await init();
  const q = sql();
  if (action === "hide") await q`UPDATE bids SET hidden=true WHERE id=${id}`;
  else if (action === "show") await q`UPDATE bids SET hidden=false WHERE id=${id}`;
  else if (action === "approve") await q`UPDATE bids SET status='paid', paid_at=now() WHERE id=${id} AND status='submitted'`;
  else if (action === "reject") await q`UPDATE bids SET status='rejected' WHERE id=${id} AND status='submitted'`;
  else if (action === "delete") await q`DELETE FROM bids WHERE id=${id} AND status<>'paid'`;
  else return NextResponse.json({ error: "bad action" }, { status: 400 });
  return NextResponse.json({ ok: true });
}
