import { NextResponse } from "next/server";
import { sql, init } from "../../../../lib/db.js";
import { isAdmin } from "../../../../lib/admin.js";
import { cleanTitle, cleanText, cleanHandle, normalizePhone, CATS } from "../../../../lib/rank.js";
export const dynamic = "force-dynamic";
const bad = (m, s = 400) => NextResponse.json({ error: m }, { status: s });
export async function GET(req) {
  if (!isAdmin(req)) return bad("login chahiye", 401);
  await init();
  const rows = await sql()`SELECT id,name,category,city,phone,phone_public,claimed,hidden,about,address,services,instagram FROM businesses ORDER BY id DESC LIMIT 300`;
  return NextResponse.json({ rows });
}
async function add(q, line) {
  const [n, c, ci, p] = line.split(",").map((s) => (s || "").trim());
  const name = cleanTitle(n), city = cleanTitle(ci);
  if (name.length < 2 || city.length < 2) return 0;
  const cat = CATS.includes((c || "").toLowerCase()) ? c.toLowerCase() : "other";
  const r = await q`INSERT INTO businesses (name,category,city,phone) VALUES (${name},${cat},${city},${normalizePhone(p)})
    ON CONFLICT (lower(name), lower(city)) DO NOTHING RETURNING id`;
  return r.length;
}
export async function POST(req) {
  if (!isAdmin(req)) return bad("login chahiye", 401);
  const b = await req.json();
  await init();
  const q = sql();
  if (b.action === "add" || b.action === "import") {
    const lines = (b.action === "add" ? [b.text] : String(b.text || "").split("\n")).filter((l) => l && l.trim()).slice(0, 200);
    let n = 0;
    for (const l of lines) n += await add(q, l);
    return NextResponse.json({ added: n, skipped: lines.length - n });
  }
  const id = Number(b.id);
  if (b.action === "public") await q`UPDATE businesses SET phone_public=${b.value === true} WHERE id=${id}`;
  else if (b.action === "hide") await q`UPDATE businesses SET hidden=true WHERE id=${id}`;
  else if (b.action === "show") await q`UPDATE businesses SET hidden=false WHERE id=${id}`;
  else if (b.action === "details") await q`UPDATE businesses SET about=${cleanText(b.about, 300) || null}, address=${cleanText(b.address, 150) || null}, services=${cleanText(b.services, 200) || null}, instagram=${cleanHandle(b.instagram)} WHERE id=${id}`;
  else return bad("bad action");
  return NextResponse.json({ ok: true });
}
