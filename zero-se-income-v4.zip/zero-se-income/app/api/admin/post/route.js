import { NextResponse } from "next/server";
import { isAdmin } from "../../../../lib/admin.js";
import { getBoard } from "../../../../lib/board.js";
import { buildCaption } from "../../../../lib/caption.js";
export const dynamic = "force-dynamic";
export async function GET(req) {
  if (!isAdmin(req)) return NextResponse.json({ error: "login chahiye" }, { status: 401 });
  const top = (await getBoard("today"))[0];
  if (!top || !top.rank) return NextResponse.json({ error: "Aaj abhi koi bid nahi, #1 nahi bana" }, { status: 404 });
  return NextResponse.json({ caption: buildCaption({ ...top, phone: top.phone }, process.env.SITE_URL || "https://your-site.vercel.app") });
}
