import { NextResponse } from "next/server";
import { safeEq } from "../../../../lib/sig.js";
import { adminToken, COOKIE } from "../../../../lib/admin.js";
export const dynamic = "force-dynamic";
export async function POST(req) {
  const { password } = await req.json();
  if (!process.env.ADMIN_PASSWORD || !process.env.SESSION_SECRET || !safeEq(password, process.env.ADMIN_PASSWORD))
    return NextResponse.json({ error: "Galat password" }, { status: 401 });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE, adminToken(), { httpOnly: true, secure: true, sameSite: "strict", path: "/", maxAge: 604800 });
  return res;
}
