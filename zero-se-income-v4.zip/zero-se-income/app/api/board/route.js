import { NextResponse } from "next/server";
import { getBoard } from "../../../lib/board.js";
export const dynamic = "force-dynamic";
export async function GET(req) {
  try {
    const tab = new URL(req.url).searchParams.get("tab") === "all" ? "all" : "today";
    return NextResponse.json({ board: await getBoard(tab) });
  } catch { return NextResponse.json({ error: "Board load nahi hua" }, { status: 500 }); }
}
