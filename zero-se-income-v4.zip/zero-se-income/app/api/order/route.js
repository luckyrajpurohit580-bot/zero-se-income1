import { NextResponse } from "next/server";
import crypto from "node:crypto";
import { sql, init } from "../../../lib/db.js";
import { validRupees, MIN_RUPEES, MAX_RUPEES } from "../../../lib/rank.js";
export const dynamic = "force-dynamic";
export async function POST(req) {
  try {
    const b = await req.json();
    const id = Number(b.businessId), rupees = Number(b.rupees);
    if (!Number.isInteger(id)) return NextResponse.json({ error: "Business chuno" }, { status: 400 });
    if (!validRupees(rupees)) return NextResponse.json({ error: `Bid ₹${MIN_RUPEES} se ₹${MAX_RUPEES} ke beech hona chahiye (poore rupaye)` }, { status: 400 });
    await init();
    const biz = await sql()`SELECT id,name FROM businesses WHERE id=${id} AND hidden=false`;
    if (!biz.length) return NextResponse.json({ error: "Business nahi mila" }, { status: 404 });
    if (!process.env.RAZORPAY_KEY_ID) {
      if (!process.env.UPI_ID) return NextResponse.json({ error: "Payment set nahi hai" }, { status: 500 });
      const oid = "manual_" + crypto.randomBytes(8).toString("hex");
      await sql()`INSERT INTO bids (order_id,link,title,amount_paise,business_id,status) VALUES (${oid},${"biz:" + id},${biz[0].name},${rupees * 100},${id},'awaiting_utr')`;
      return NextResponse.json({ manual: true, orderId: oid, ref: "ZSI" + oid.slice(7, 13).toUpperCase(), rupees, upiId: process.env.UPI_ID, upiName: process.env.UPI_NAME || "ZERO SE INCOME", qr: process.env.NEXT_PUBLIC_UPI_QR || null });
    }
    const key = process.env.RAZORPAY_KEY_ID, secret = process.env.RAZORPAY_KEY_SECRET;
    const r = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Basic " + Buffer.from(key + ":" + secret).toString("base64") },
      body: JSON.stringify({ amount: rupees * 100, currency: "INR", receipt: "zsi_" + Date.now() })
    });
    const o = await r.json();
    if (!r.ok) return NextResponse.json({ error: "Payment shuru nahi hua, baad mein try karo" }, { status: 502 });
    await sql()`INSERT INTO bids (order_id,link,title,amount_paise,business_id) VALUES (${o.id},${"biz:" + id},${biz[0].name},${rupees * 100},${id})`;
    return NextResponse.json({ orderId: o.id, amount: o.amount, keyId: key });
  } catch { return NextResponse.json({ error: "Kuch gadbad hui" }, { status: 500 }); }
}
