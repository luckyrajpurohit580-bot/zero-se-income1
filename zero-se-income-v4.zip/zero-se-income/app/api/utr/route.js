import { NextResponse } from "next/server";
import { sql, init } from "../../../lib/db.js";
export const dynamic = "force-dynamic";
export async function POST(req) {
  try {
    const { order_id, utr } = await req.json();
    const u = String(utr || "").trim();
    if (!/^\d{12}$/.test(u) || !String(order_id).startsWith("manual_"))
      return NextResponse.json({ error: "12 ank ka UTR number daalo" }, { status: 400 });
    await init();
    const r = await sql()`UPDATE bids SET status='submitted', payment_id=${u} WHERE order_id=${order_id} AND status='awaiting_utr' RETURNING id`;
    if (!r.length) return NextResponse.json({ error: "Order nahi mila" }, { status: 404 });
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "Ye UTR pehle use ho chuka hai ya kuch gadbad hui" }, { status: 409 }); }
}
