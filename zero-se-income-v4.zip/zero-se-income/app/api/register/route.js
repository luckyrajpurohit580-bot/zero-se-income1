import { NextResponse } from "next/server";
import { sql, init } from "../../../lib/db.js";
import { cleanTitle, cleanText, cleanHandle, normalizePhone, normalizeLink, CATS } from "../../../lib/rank.js";
export const dynamic = "force-dynamic";
export async function POST(req) {
  try {
    const b = await req.json();
    const name = cleanTitle(b.name), city = cleanTitle(b.city);
    const category = CATS.includes(b.category) ? b.category : "other";
    const phone = normalizePhone(b.phone);
    const card = b.cardUrl ? normalizeLink(b.cardUrl) : null;
    if (name.length < 2 || city.length < 2 || !phone) return NextResponse.json({ error: "Naam, shahar aur sahi 10 digit mobile number daalo" }, { status: 400 });
    await init();
    const r = await sql()`INSERT INTO businesses (name,category,city,phone,card_url,phone_public,claimed,about,address,services,instagram)
      VALUES (${name},${category},${city},${phone},${card},${b.consent === true},true,${cleanText(b.about, 300) || null},${cleanText(b.address, 150) || null},${cleanText(b.services, 200) || null},${cleanHandle(b.instagram)})
      ON CONFLICT (lower(name), lower(city)) DO NOTHING RETURNING id,name`;
    if (!r.length) return NextResponse.json({ error: "Ye business pehle se listed hai. Contact par likho, hum aapko claim karwa denge." }, { status: 409 });
    return NextResponse.json({ id: r[0].id, name: r[0].name });
  } catch { return NextResponse.json({ error: "Kuch gadbad hui" }, { status: 500 }); }
}
