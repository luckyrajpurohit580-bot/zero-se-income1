import Wall from "./Wall.js";
import { getBoard } from "../lib/board.js";
export const dynamic = "force-dynamic";
export default async function Home() {
  let today = [], all = [], dbError = false;
  try { [today, all] = await Promise.all([getBoard("today"), getBoard("all")]); }
  catch { dbError = true; }
  return <Wall initial={{ today, all }} dbError={dbError} />;
}
